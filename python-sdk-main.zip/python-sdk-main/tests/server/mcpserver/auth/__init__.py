"""Tests for the MCP server auth components."""
